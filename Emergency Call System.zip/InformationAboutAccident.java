package emr;
import java.awt.*;
import java.awt.event.*;
import java.applet.*;
import java.sql.*;
public class InformationAboutAccident extends Frame implements ActionListener
{ 
   Connection con;
   Statement st;
   PreparedStatement pst;
   ResultSet rec;
   Frame frm;
   CheckboxGroup cb1,cb2,cb3;
   Choice d1;
   Checkbox c1,c2,c3,c4,c5,c6,c7,C8,C9;
   Button b1,b2,b3,b4,b5;
   TextField t1,t2,t3,t4,t5,t6,t7,t8,t9,t10;
   Label l1,l2,l3,l4,l5,l6,l7,l8,l9,l10,l11,l12,l13,l14;
   String a1="",a2="",a3="",a4="",a5="",a6="",a7="",a8="",a9="",a10="",a11="",a12="",a13="",a14="";

  public InformationAboutAccident()
  { 
     frm=new Frame("INFORMATION ABOUT ACCIDENT");
     l11=new Label("TYPES OF ACCIDENT");
     cb1=new CheckboxGroup();
     c1=new Checkbox("ROAD ACCIDENT",true,cb1);
     c2=new Checkbox("OTHER",false,cb1);

     l12=new Label("VEHICLES TYPE");
     cb2=new CheckboxGroup();
     c3=new Checkbox("TWO WHEELER",true,cb2);
     c4=new Checkbox("FOUR WHEELER",false,cb2);

     l13=new Label("CONDITIONS OF PERSON");
     cb3=new CheckboxGroup();
     c5=new Checkbox("ONSPOT DEATH",true,cb3);
     c6=new Checkbox("SOME INJURED",false,cb3);
     c7=new Checkbox("SERIOUS INJURED",false,cb3);

     l14=new Label("SELECT AREA");
     d1=new Choice();


     l1=new Label("CASE NUMBER");
     t1=new TextField();
     l2=new Label("NAME OF CALLER");
     t2=new TextField();
     l3=new Label("LOCATION OF CALLER");
     t3=new TextField(); 
     l4=new Label("TIME OF ACCIDENT");
     t4=new TextField();
     l5=new Label("VEHICLE NUMBER");
     t5=new TextField();
     l6=new Label("VEHICLES NUMBER 2ND");
     t6=new TextField();
     l7=new Label("AMBULANCE NUMBER");
     t7=new TextField();
     l8=new Label("POLICE STATION NUMBER");
     t8=new TextField();
     l9=new Label("FIRE STATION NUMBER");
     t9=new TextField();
     l10=new Label("CONTACT NUMBER");
     t10=new TextField();

     b1=new Button("MAIN FORM");
     b2=new Button("SAVE RECORD");    
     b3=new Button("SEARCH RECORD");
     b4=new Button("NEW RECORD");   
     b5=new Button("ADD NEW AREA");      
   

  }


  public void setupInformationAboutAccident()
{    
     l11.setBounds(100,100,200,30);
     c1.setBounds(100,140,150,30);
     c2.setBounds(100,170,150,30);

     l12.setBounds(310,100,200,30);
     c3.setBounds(310,140,150,30);
     c4.setBounds(310,170,150,30);

     l13.setBounds(520,100,200,30);
     c5.setBounds(520,140,150,30);
     c6.setBounds(520,170,150,30);
     c7.setBounds(520,200,150,30);

     l14.setBounds(730,100,200,30);

     d1.add("DEHRADUN");
     d1.add("DELHI"); 
     d1.add("MUMBAI");
     d1.add("UTTARPARDESH");
     d1.setBounds(730,130,150,25);

     b5.addActionListener(this);
     b5.setBounds(730,170,150,40);
    

     l1.setBounds(100,250,200,30);
     t1.setBounds(310,250,150,30);
     l2.setBounds(100,290,200,30);
     t2.setBounds(310,290,150,30);
     l10.setBounds(500,290,150,30);
     t10.setBounds(670,290,150,30);
     l3.setBounds(100,330,150,30);
     t3.setBounds(310,330,150,30);
     l4.setBounds(100,370,150,30);
     t4.setBounds(310,370,150,30);
     l5.setBounds(100,410,150,30);
     t5.setBounds(310,410,150,30);
     l6.setBounds(100,450,150,30);
     t6.setBounds(310,450,150,30);
     l7.setBounds(100,490,150,30);
     t7.setBounds(310,490,150,30);
     l8.setBounds(100,530,150,30);
     t8.setBounds(310,530,150,30);
     l9.setBounds(100,570,150,30);
     t9.setBounds(310,570,150,30);

     b1.addActionListener(this);
     b1.setBounds(500,330,150,40);
     b2.addActionListener(this);
     b2.setBounds(500,390,150,40);
     b3.addActionListener(this);
     b3.setBounds(500,450,150,40);
     b4.addActionListener(this);
     b4.setBounds(500,520,150,40);

     frm.setLayout(null);
      frm.add(l11);
     frm.add(l12);
     frm.add(l13); 
     frm.add(l14);
     frm.add(d1);
     frm.add(c1); 
     frm.add(c2);
     frm.add(c3); 
     frm.add(c4); 
     frm.add(c5);
     frm.add(c6);
     frm.add(c7); 


     frm.add(l1);
     frm.add(l2);
     frm.add(l10);
     frm.add(l3);
     frm.add(l4);
     frm.add(t1);
     frm.add(t2);
     frm.add(t10);
     frm.add(t3);
     frm.add(t4);
     frm.add(l5);
     frm.add(l6);
     frm.add(l7);   
     frm.add(t5);
     frm.add(t6);
     frm.add(t7);
     frm.add(l8);   
     frm.add(t8);
     frm.add(l9);   
     frm.add(t9);
     frm.add(b1);
     frm.add(b2);
     frm.add(b3);
     frm.add(b4);
     frm.add(b5);
     frm.setSize(1500,1500); 
     frm.setVisible(true); 

}

public void getFillValue()
{
  try
  {

    if(c1.getState()==true)
     {
       a1="ROAD ACCIDENT";
     }

   else
     {
       a1="OTHER ACCIDENT";
     } 



 if(c3.getState()==true)
     {
       a2="TWO WHEELER";
     }

   else
     {
       a2="FOUR WHEELER";
     } 



    if(c5.getState()==true)
     {
       a3="ONSPOT DEATH";
     }
   else if(c6.getState()==true)
     {
       a3="SOME INJURED";

     } 
   else
     {
       a3="SERIOUS INJURED";

     } 




   a4=d1.getSelectedItem();   
   a5=t1.getText();
   a6=t2.getText();
   a7=t3.getText();
   a8=t4.getText();
   a9=t5.getText();
   a10=t6.getText();
   a11=t7.getText();
   a12=t8.getText();
   a13=t9.getText();
   a14=t10.getText();
   }
   catch(Exception ex)
  {
    System.out.println("VALUR ERROR="+ex);
   }
}

public void conn()
{
 try
 { 
   Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
   con=DriverManager.getConnection("jdbc:odbc:DSNEMR");
 }
 catch(Exception ex)
 {
  System.out.println(ex);
 }
}
public void putData()
{
 try
 {
   pst=con.prepareStatement("insert into infoabutaccdnt values('"+a1+"','"+a2+"','"+a3+"','"+a4+"','"+a5+"','"+a6+"','"+a7+"','"+a8+"','"+a9+"','"+a10+"','"+a11+"','"+a12+"','"+a13+"','"+a14+"')");
   pst.executeUpdate();
 }
 catch(SQLException se)
 {
  System.out.println(se);
 }
}
public void setID(String ID)
{
t1.setText(ID);
}
public void actionPerformed(ActionEvent ae)
{
   if(ae.getSource()==b1)
   {  
     getFillValue();
     conn();
     putData();
   } 

 if(ae.getSource()==b5)
   {  
   AddNewArea obj=new AddNewArea();
     obj.setupaddnewarea();
   } 


}
}
