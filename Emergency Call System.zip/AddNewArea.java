 package emr;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class AddNewArea extends Frame implements ActionListener
  {
   Connection con;
   Statement st;
   PreparedStatement pst;
   ResultSet rec;
   Frame frm;
   Button b1,b2;
   TextField t1,t2,t3,t4,t5,t6;
   Label l1,l2,l3,l4,l5,l6;
   String a1="",a2="",a3="",a4="",a5="",a6="";
    public AddNewArea()
    {
     frm=new Frame(" ADD NEW AREA");
     l1=new Label("Add New Area");
     t1=new TextField();
     l2=new Label("Area Name");
     t2=new TextField();
     l3=new Label("Police Station Number");
     t3=new TextField();
     l4=new Label("Fire Station Number");
     t4=new TextField();
     l5=new Label("Power Station Number");
     t5=new TextField();
     l6=new Label("Ambulance Number");
     t6=new TextField();
     b1=new Button("Back");
     b2=new Button("Next");
 
     }
     public void setupaddnewarea()
     {
     l1.setBounds(100,100,200,30);
     t1.setBounds(310,100,150,30);
     l2.setBounds(100,150,200,30);
     t2.setBounds(310,150,150,30);
     l3.setBounds(100,200,200,30);
     t3.setBounds(310,200,150,30);
     l4.setBounds(100,250,200,30);
     t4.setBounds(310,250,150,30);
     l5.setBounds(100,300,200,30);
     t5.setBounds(310,300,150,30);
     l6.setBounds(100,350,200,30);
     t6.setBounds(310,350,150,30);

     b1.addActionListener(this);
     b1.setBounds(100,400,150,40);
     b2.addActionListener(this);
     b2.setBounds(310,400,150,40);
     frm.setLayout(null);

     frm.add(l1);
     frm.add(l2);
     frm.add(l3);
     frm.add(l4);
     frm.add(l5);
     frm.add(l6); 
     frm.add(t1);
     frm.add(t2);
     frm.add(t3);
     frm.add(t4);
     frm.add(t5);
     frm.add(t6);
     frm.add(b1);
     frm.add(b2);
     frm.setSize(500,500); 
     frm.setVisible(true);


      }

public void getFillValue()
{
  try
  { 
   a1=t1.getText();
   a2=t2.getText();
   a3=t3.getText();
   a4=t4.getText();
   a5=t5.getText();
   a6=t6.getText();

   }
   catch(Exception ex)
  {
    System.out.println("VALUR ERROR="+ex);
   }
}

public void conn()
{
 try
 { 
   Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
   con=DriverManager.getConnection("jdbc:odbc:DSNEMR");
 }
 catch(Exception ex)
 {
  System.out.println(ex);
 }
}

public void putData()
{
 try
 {
   pst=con.prepareStatement("insert into addnewarea  values('"+a1+"','"+a2+"','"+a3+"','"+a4+"','"+a5+"','"+a6+"')");
   pst.executeUpdate();
 }
 catch(SQLException se)
 {
  System.out.println(se);
 }
}



public void actionPerformed(ActionEvent ae)
{
     if(ae.getSource()==b1)
   {  
     getFillValue();
     conn();
     putData();

   } 

}


   }










