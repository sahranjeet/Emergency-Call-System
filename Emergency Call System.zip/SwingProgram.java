import javax.swing.*;
import java.awt.event.*;
import java.applet.*;

public class SwingProgram extends JFrame implements ActionListener
{
   JFrame frm;
   JButton b1,b2,b3,b4,b5,b6,b7,b8,b9,b10;
   JTextField t1;
   JLabel l1;

  public SwingProgram()
  { 
    frm=new JFrame("FIRE STATION INFORMATION");
     l1=new JLabel("EMERGENCY ID");
     t1=new JTextField();
     b1=new JButton("BOTTON 1");
     b2=new JButton("BOTTON 2");  
     b3=new JButton("BOTTON 3");
     b4=new JButton("BOTTON 4");
     b5=new JButton("BOTTON 5");  
     b6=new JButton("BOTTON 6");
     b7=new JButton("BOTTON 7");
     b8=new JButton("BOTTON 8");    
     b9=new JButton("BOTTON 9");
     b10=new JButton("BOTTON 10");
  }

  public void setupSwingProgram()
  {    
     l1.setBounds(100,100,150,25);
     t1.setBounds(360,100,150,25);

     b1.addActionListener(this);
     b1.setBounds(100,350,100,30);
     b2.addActionListener(this);
     b2.setBounds(220,350,100,30);
     b3.addActionListener(this);
     b3.setBounds(340,350,100,30);
     b4.addActionListener(this);
     b4.setBounds(460,350,100,30);
     b5.addActionListener(this);
     b5.setBounds(580,350,100,30);
     b6.addActionListener(this);
     b6.setBounds(700,350,100,30);
     b7.addActionListener(this);
     b7.setBounds(820,350,100,30);
     b8.addActionListener(this);
     b8.setBounds(940,350,100,30);
     b9.addActionListener(this);
     b9.setBounds(1060,350,100,30);
     b10.addActionListener(this);
     b10.setBounds(1180,350,100,30);

     frm.setLayout(null);
     frm.add(l1);
     frm.add(t1);
     frm.add(b1);
     frm.add(b2);
     frm.add(b3);
     frm.add(b4);
     frm.add(b5);
     frm.add(b6);
     frm.add(b7);
     frm.add(b8);
     frm.add(b9);
     frm.add(b10);
     frm.setSize(1500,1500); 
     frm.setVisible(true); 
}
public void actionPerformed(ActionEvent ae)
{

}

 public static void main(String []ab)
 {

 SwingProgram obj=new SwingProgram();
     obj.setupSwingProgram();
}
}