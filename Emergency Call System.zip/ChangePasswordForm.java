package emr;
import java.awt.*;
import java.awt.event.*;
import java.applet.*;
public class ChangePasswordForm extends Frame implements ActionListener
{ 
   Frame frm;
   Button b1,b2;
   TextField t1,t2,t3,t4;
   Label l1,l2,l3,l4;
   String a1="",a2="",a3="",a4="";

  public ChangePasswordForm()
  {
   frm=new Frame("CHANE PASSWORD FORM");
     l1=new Label("Enter User ID");
     t1=new TextField();
     l2=new Label("Enter Older Password");
     t2=new TextField();
     l3=new Label("Enter New Password");
     t3=new TextField();   
     l4=new Label("Re-Enter New Password");
     t4=new TextField();
     b1=new Button("INSERT");
     b2=new Button("EXIT");
  }


  public void setupChangePasswordForm()
{    

     frm.setLayout(null);
     l1.setBounds(100,100,150,25);
     t1.setBounds(260,100,150,25);
    
     frm.setLayout(null);
     l2.setBounds(100,150,150,25);
     t2.setBounds(260,150,150,25);

     frm.setLayout(null);
     l3.setBounds(100,200,150,25);
     t3.setBounds(260,200,150,25);

     frm.setLayout(null);
     l4.setBounds(100,250,150,25);
     t4.setBounds(260,250,150,25);
    
     frm.setLayout(null);
     b1.addActionListener(this);
     b1.setBounds(260,300,150,25);

     frm.setLayout(null);
     b2.addActionListener(this);
     b2.setBounds(430,300,150,25);

     frm.add(l1);
     frm.add(l2);
     frm.add(l3);
     frm.add(l4);
     frm.add(t1);
     frm.add(t2);
     frm.add(t3);
     frm.add(t4); 
     frm.add(b1);
     frm.add(b2); 
     frm.setSize(500,500);
     frm.setVisible(true);
}


public void getFillValue()
{
  try
  {
   a1=t1.getText();
   a2=t2.getText();
   a3=t3.getText();
   a4=t4.getText();
   }
   catch(Exception ex)
  {
    System.out.println("VALUR ERROR="+ex);
   }
}
public void actionPerformed(ActionEvent ae)
{


}
}
/*<applet code="ChangePasswordForm.java" height="500" width="700">
</applet>*/