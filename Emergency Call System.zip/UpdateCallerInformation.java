package emr;
import java.awt.*;
import java.awt.event.*;
import java.applet.*;
import java.sql.*;
public class UpdateCallerInformation extends Frame implements ActionListener
{ 
   Connection con;
   Statement st;
   PreparedStatement pst;
   ResultSet rec;
   CheckboxGroup cb1;
   Checkbox c1,c2;
   Frame frm;
   Button b0,b1,b2,b3,b4,b5,b6,b7,b8,b9,b10;
   TextField t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13,t14,t15,t16,t17;
   Label l1,l2,l3,l4,l5,l6,l7,l8,l9,l10,l11,l12,l13,l14,l15,l16,l17,l18;
   String a1="",a2="",a3="",a4="",a5="",a6="",a7="",a8="",a9="",a10="",a11="",a12="",a13="",a14="",a15="",a16="",a17="",a18="";

 public void paint(Graphics g)
 {
   g.setColor(Color.red);
   g.drawRect(60,60,870,460);
   g.drawRect(970,20,200,540);
 }

  public UpdateCallerInformation()
  {
     frm=new Frame("CALLER INFORMATIONS");
     l1=new Label("EMERGENCY ID");
     t1=new TextField();
     l2=new Label("CALLER NAME");
     t2=new TextField();
     l3=new Label("FATHER NAME");
     t3=new TextField();
     l4=new Label("MOTHER NAME");
     t4=new TextField();
     l5=new Label("STATE");
     t5=new TextField();
     l6=new Label("STR/MOHALA");
     t6=new TextField();
     l7=new Label("MOBILE NUMBER");
     t7=new TextField();


  /* AGE AND BLOODGROUP */

     l8=new Label("AGE");
     t8=new TextField();
     l9=new Label("AGE");
     t9=new TextField();
     l10=new Label("AGE");
     t10=new TextField();
     l11=new Label("DISTRICT");
     t11=new TextField();
     l12=new Label("HOUSE NO.");
     t12=new TextField();

     l13=new Label("BLOOD GROUP");
     t13=new TextField();
     l14=new Label("BLOOD GROUP");
     t14=new TextField();
     l15=new Label("BLOOD GROUP");
     t15=new TextField();
     l16=new Label("VILL/TOWN");
     t16=new TextField();
     l17=new Label("TELL PHONE NO.");
     t17=new TextField();

     l18=new Label("MARRIAGE STATUS");
     cb1=new CheckboxGroup();
     c1=new Checkbox("MARRIED",true,cb1);
     c2=new Checkbox("UNMARRIED",false,cb1);


     b1=new Button("SEARCH RECORD");
     b2=new Button("UPDATE");
     b0=new Button("BACK");

   /* RECTANGLE BUTTON */
 
     b3=new Button("ADD NEW CALLER");
     b4=new Button("CHILD NEW INFO.");
     b5=new Button("POLICE");
     b6=new Button("HOSPITAL");
     b7=new Button("FIRE STATION");
     b8=new Button("POWER STATION");
     b9=new Button("CASE OF ACCIDENT");
     b10=new Button("EXIT");

  }



  public void setupUpdateCallerInformation()
{    
     l1.setBounds(100,100,100,25);
     t1.setBounds(260,100,150,25);
    
     l2.setBounds(100,150,100,25);
     t2.setBounds(260,150,150,25);

     l3.setBounds(100,200,100,25);
     t3.setBounds(260,200,150,25);

     l4.setBounds(100,250,100,25);
     t4.setBounds(260,250,150,25);
     l5.setBounds(100,300,100,25);
     t5.setBounds(260,300,150,25);

     l6.setBounds(100,350,100,25);
     t6.setBounds(260,350,150,25);
     l7.setBounds(100,400,100,25);
     t7.setBounds(260,400,150,25);

  /* AGE AND BLOODGROUP */

     l8.setBounds(470,150,80,25);
     t8.setBounds(550,150,100,25);

     l9.setBounds(470,200,80,25);
     t9.setBounds(550,200,100,25);

     l10.setBounds(470,250,80,25);
     t10.setBounds(550,250,100,25);

     l11.setBounds(470,300,80,25);
     t11.setBounds(550,300,100,25);

     l12.setBounds(470,350,80,25);
     t12.setBounds(550,350,100,25);


     l13.setBounds(680,150,100,25);
     t13.setBounds(790,150,100,25);

     l14.setBounds(680,200,100,25);
     t14.setBounds(790,200,100,25);

     l15.setBounds(680,250,100,25);
     t15.setBounds(790,250,100,25);

     l16.setBounds(680,300,100,25);
     t16.setBounds(790,300,100,25);

     l17.setBounds(680,350,100,25);
     t17.setBounds(790,350,100,25);

     l18.setBounds(470,400,125,30);
     c1.setBounds(600,400,100,30);
     c2.setBounds(600,440,100,30);

     b1.addActionListener(this);
     b1.setBounds(760,70,150,50);
     b2.addActionListener(this);
     b2.setBounds(760,440,150,50);
     b0.addActionListener(this);
     b0.setBounds(760,480,150,50);


     frm.setLayout(null);

     frm.add(l1);
     frm.add(l2);
     frm.add(l3);
     frm.add(l4);
     frm.add(l5);
     frm.add(l6);
     frm.add(l7);
     frm.add(l8);
     frm.add(l9);
     frm.add(l10);
     frm.add(l11);
     frm.add(l12);
     frm.add(l13);
     frm.add(l14);
     frm.add(l15);
     frm.add(l16);
     frm.add(l17);
     
     frm.add(l18);
     frm.add(c1);
     frm.add(c2);

     frm.add(t1);
     frm.add(t2);
     frm.add(t3);
     frm.add(t4);    
     frm.add(t5);
     frm.add(t6);
     frm.add(t7);
     frm.add(t8); 
     frm.add(t9);
     frm.add(t10); 
     frm.add(t11);
     frm.add(t12);
     frm.add(t13);
     frm.add(t14);
     frm.add(t15); 
     frm.add(t16);
     frm.add(t17);
     frm.add(b1);
     frm.add(b2);
     frm.add(b0);  

    /* RECTANGLE BUTTON */
 
     b3.addActionListener(this);
     b3.setBounds(990,50,150,35);
     b4.addActionListener(this);
     b4.setBounds(990,110,150,35);
     b5.addActionListener(this);
     b5.setBounds(990,170,150,35);
     b6.addActionListener(this);
     b6.setBounds(990,230,150,35);
     b7.addActionListener(this);
     b7.setBounds(990,290,150,35);
     b8.addActionListener(this);
     b8.setBounds(990,350,150,35);
     b9.addActionListener(this);
     b9.setBounds(990,410,150,35);
     b10.addActionListener(this);
     b10.setBounds(990,470,150,35);




    
     frm.setLayout(null);
     frm.add(b3);
     frm.add(b4);
     frm.add(b5);
     frm.add(b6);
     frm.add(b7);
     frm.add(b8);
     frm.add(b9);
     frm.add(b10);
    frm.setSize(600,500);
    frm.setVisible(true);
}

public void getFillValue()
{
  try
  {
   a1=t1.getText();
   a2=t2.getText();
   a3=t3.getText();
   a4=t4.getText();
   a5=t5.getText();
   a6=t6.getText();
   a7=t7.getText();
   a8=t8.getText();
   a9=t9.getText();
   a10=t10.getText();
   a11=t11.getText();
   a12=t12.getText();

   a14=t13.getText();
   a15=t14.getText();
   a16=t15.getText();
   a17=t16.getText();
   a18=t17.getText();

    if(c1.getState()==true)
     {
       a13="MARRIED";
     }
     else
     {
      a13="UNMARRIED";
     }
   }
   catch(Exception ex)
  {
    System.out.println("VALUR ERROR="+ex);
   }
}


public void conn()
{
 try
 { 
   Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
   con=DriverManager.getConnection("jdbc:odbc:DSNEMR");
 }
 catch(Exception ex)
 {
  System.out.println(ex);
 }
}
public void updateData()
{
 try
 {
   pst=con.prepareStatement("update clrinfo set clrnam='"+a2+"',fthrnam='"+a3+"',motrnam='"+a4+"',stat='"+a5+"',mohla='"+a6+"',moblno='"+a7+"',ag1='"+a8+"',ag2='"+a9+"',ag3='"+a10+"',dstr='"+a11+"',homno='"+a12+"',stats='"+a13+"',bldgp1='"+a14+"',bldgp2='"+a15+"',bldgp3='"+a16+"',vltwn='"+a17+"',tellphno='"+a18+"' where emrngcno='"+a1+"'");
   pst.executeUpdate();
 }
 catch(SQLException se)
 {
  System.out.println(se);
 }
}


public void searchData()
{
  try
  {
    st=con.createStatement();
    String str=t1.getText();
    rec=st.executeQuery("Select *from clrinfo where emrngcno='"+str+"'");
    if(rec.next())
    {
      t2.setText(rec.getString(2));
      t3.setText(rec.getString(3));
      t4.setText(rec.getString(4));
      t5.setText(rec.getString(5));
      t6.setText(rec.getString(6));
      t7.setText(rec.getString(7));
      t8.setText(rec.getString(8));
      t9.setText(rec.getString(9));
      t10.setText(rec.getString(10));
      t11.setText(rec.getString(11));
      t12.setText(rec.getString(12));

      str=rec.getString(13);
      if(str.equals("MARRIED"))
       {
           c1.setState(true);
        }
      else
        {
          c2.setState(true);
        }
      t13.setText(rec.getString(14));
      t14.setText(rec.getString(15));
      t15.setText(rec.getString(16));
      t16.setText(rec.getString(17));
      t17.setText(rec.getString(18));
    }
   }
   catch(Exception ex)
   {
     System.out.println(ex);
   }
}
public void actionPerformed(ActionEvent ae)
{
    
   if(ae.getSource()==b2)
   {  
     getFillValue();
     conn();
     updateData();
   }
  else if(ae.getSource()==b1)
  {
     conn();
     searchData();
  }




}
}
