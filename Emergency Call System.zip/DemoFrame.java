package emr;
import java.awt.*;
import java.awt.event.*;
public class DemoFrame extends Frame implements ActionListener
 {
   Frame frm;
   Label l1,l2;
   TextField t1,t2;
   Button b1;
   
   public DemoFrame()
    {
      frm=new Frame("TEST FORM");
      l1=new Label("ENTER THE NUMBER");
      l2=new Label("RESULT"); 
      t1=new TextField();
      t2=new TextField();
      b1=new Button("OK");
    }
    
    public void setupDemoFrame()
    {
      frm.setLayout(null); 
      l1.setBounds(50,50,150,25); 
      t1.setBounds(210,50,150,25); 

      l2.setBounds(50,90,150,25); 
      t2.setBounds(210,90,150,25); 
      
      b1.addActionListener(this);
      b1.setBounds(50,130,100,30);
  
      frm.add(l1);
      frm.add(l2);
      frm.add(t1);
      frm.add(t2);
      frm.add(b1);
      frm.setSize(600,500);
      frm.setVisible(true);
     }

     public void actionPerformed(ActionEvent ae)
     {

     }

 }