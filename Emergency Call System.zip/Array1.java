import java.util.Scanner;
class Array1
{
  public static void main(String []ab)
  {
   Scanner sc=new Scanner(System.in);
   System.out.println("ENTER THE NUMBER OF ELEMENTS IN AN ARRAY");
   int n=new sc.nextLine();
   int arr[]=new arr[n];
   fot(i=0;i<n;i++)
   {
    arr[i]=sc.nextLine();

   }
System.out.println("ARRAY ELEMNTS ARE:-"+arr[i]);




  }







}
