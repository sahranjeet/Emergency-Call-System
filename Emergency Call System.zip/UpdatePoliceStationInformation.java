package emr;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class UpdatePoliceStationInformation extends Frame implements ActionListener
{ 
   Connection con;
   Statement st;
   PreparedStatement pst;
   ResultSet rec;
   Frame frm;
   Button b0,b1,b2;
   TextField t1,t2,t3,t4,t5,t6,t7,t8;
   Label l1,l2,l3,l4,l5,l6,l7,l8,l0;
   String a1="",a2="",a3="",a4="",a5="",a6="",a7="",a8="";

 public void paint(Graphics g)
 {
   g.setColor(Color.red);
   g.drawRect(60,60,870,460);
 }

  public UpdatePoliceStationInformation()
  { 
    frm=new Frame("POLICE STATION INFORMATION");
     l1=new Label("NAME OF POLICE STATION");
     t1=new TextField();
     l2=new Label("POLICE STATION PHONE NO.");
     t2=new TextField();
     l3=new Label("CONTROL ROOM NO.");
     t3=new TextField(); 
     l4=new Label("EMERGENCY NO.");
     t4=new TextField();
     l5=new Label("DISTANCE");
     t5=new TextField();
     l6=new Label("CO CITY PHONE NO.");
     t6=new TextField();
     l7=new Label("DIG PHONE NO.");
     t7=new TextField();
     l8=new Label("CALLER ID");
     t8=new TextField();
     b0=new Button("SEARCH");  
     b1=new Button("UPDATE");
     b2=new Button("BACK");   
  
       

  }


  public void setupUpdatePoliceStationInformation()
{    
     l1.setBounds(100,100,200,25);
     t1.setBounds(310,100,150,25);
     l2.setBounds(100,150,200,25);
     t2.setBounds(310,150,150,25);
     l3.setBounds(100,200,150,25);
     t3.setBounds(310,200,150,25);
     l4.setBounds(100,250,100,25);
     t4.setBounds(310,250,150,25);
     l5.setBounds(100,300,100,25);
     t5.setBounds(310,300,150,25);
     l6.setBounds(100,350,200,25);
     t6.setBounds(310,350,150,25);
     l7.setBounds(100,400,100,25);
     t7.setBounds(310,400,150,25);
     l8.setBounds(100,450,100,25);
     t8.setBounds(310,450,150,25);
     b0.addActionListener(this);
     b0.setBounds(310,500,100,30);
     b1.addActionListener(this);
     b1.setBounds(430,500,100,30);
     b2.addActionListener(this);
     b2.setBounds(550,500,100,30);
     
     frm.setLayout(null);
     frm.add(l1);
     frm.add(l2);
     frm.add(l3);
     frm.add(l4);
     frm.add(t1);
     frm.add(t2);
     frm.add(t3);
     frm.add(t4);
     frm.add(l5);
     frm.add(l6);
     frm.add(l7);   
     frm.add(t5);
     frm.add(t6);
     frm.add(t7);
     frm.add(l8);   
     frm.add(t8);
     frm.add(b0);
     frm.add(b1);
     frm.add(b2);
     frm.setSize(700,500); 
     frm.setVisible(true); 

}


public void getFillValue()
{
  try
  {
   a1=t1.getText();
   a2=t2.getText();
   a3=t3.getText();
   a4=t4.getText();
   a5=t5.getText();
   a6=t6.getText();
   a7=t7.getText();
   a8=t8.getText();
   }
   catch(Exception ex)
  {
    System.out.println("VALUR ERROR="+ex);
   }
}
public void conn()
{
 try
 { 
   Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
   con=DriverManager.getConnection("jdbc:odbc:DSNEMR");
 }
 catch(Exception ex)
 {
  System.out.println(ex);
 }
}
public void updateData()
{
 try
 {
   pst=con.prepareStatement("update polcstsninfo set nampolcstsn='"+a1+"',polcstsnphno='"+a2+"',cntrromno='"+a3+"',emrngcno='"+a4+"',distnc='"+a5+"',coctphno='"+a6+"',digphno='"+a7+"' where clrid='"+a8+"'");
   pst.executeUpdate();
 }
 catch(SQLException se)
 {
  System.out.println(se);
 }
}

public void searchData()
{
  try
  {
    st=con.createStatement();
    String str=t8.getText();
    rec=st.executeQuery("Select *from polcstsninfo  where clrid='"+str+"'");
    if(rec.next())
    {
      t1.setText(rec.getString(1));
      t2.setText(rec.getString(2));
      t3.setText(rec.getString(3));
      t4.setText(rec.getString(4));
      t5.setText(rec.getString(5));
      t6.setText(rec.getString(6));
      t7.setText(rec.getString(7));


    }
   }
   catch(Exception ex)
   {
     System.out.println(ex);
   }
}

public void actionPerformed(ActionEvent ae)
{
  if(ae.getSource()==b1)
   {  
     getFillValue();
     conn();
     updateData();
   }
   else if(ae.getSource()==b0)
  {
     conn();
     searchData();
  }

}
}
