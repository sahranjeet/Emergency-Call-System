package emr;
import java.awt.*;
import java.awt.event.*;
import java.applet.*;
public class ForgetPasswordForm extends Frame implements ActionListener
{ 
   Frame frm;
   Button b1,b2,b3;
   TextField t1,t2;
   Label l1,l2,l3,l4;
   String a1="",a2="";

  public ForgetPasswordForm()
  {
   frm=new Frame("FORGET PASSWORD FORM");
     l1=new Label("Enter User ID");
     t1=new TextField();
     l2=new Label("Your Security Question Is:-");
     l3=new Label("Give Answer");
     t2=new TextField();   
     l4=new Label("Your Password Is:-");
     b1=new Button("Ok");
     b2=new Button("Retrieve");
     b3=new Button("Exit");
  }


  public void setupForgetPasswordForm()
{    

     l1.setBounds(100,100,150,25);
     t1.setBounds(260,100,150,25);

     l2.setBounds(100,150,200,25);

     l3.setBounds(100,200,150,25);
     t2.setBounds(260,200,150,25);

     l4.setBounds(100,250,150,25);
    
     b1.addActionListener(this);
     b1.setBounds(430,100,150,25);

     b2.addActionListener(this);
     b2.setBounds(430,200,150,25);

     b3.addActionListener(this);
     b3.setBounds(430,300,150,25);
     frm.setLayout(null);
     frm.add(l1);
     frm.add(l2);
     frm.add(l3);
     frm.add(l4);
     frm.add(t1);
     frm.add(t2);
     frm.add(b1);
     frm.add(b2); 
     frm.add(b3);
     frm.setSize(500,500);
     frm.setVisible(true);
}

public void getFillValue()
{
  try
  {
   a1=t1.getText();
   a2=t2.getText();
   }
   catch(Exception ex)
  {
    System.out.println("VALUR ERROR="+ex);
   }
}
public void actionPerformed(ActionEvent ae)
{


}
}
