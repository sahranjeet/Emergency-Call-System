package emr;
import java.awt.*;
import java.awt.event.*;
import java.applet.*;
import java.sql.*;
public class SearchChildrensInformation extends Frame implements ActionListener
{ 
   Connection con;
   Statement st;
   PreparedStatement pst;
   ResultSet rec;
   Frame frm;
   Button b0,b1;
   TextField t1,t2,t3,t4,t5,t6,t7,t8,t9,t10;
   Label l1,l2,l3,l4,l5,l6,l7,l8,l9,l10;
   String a1="",a2="",a3="",a4="",a5="",a6="",a7="",a8="",a9="",a10="";


   public SearchChildrensInformation()
   {
     frm=new Frame("CHILDRENS INFORMATION");
     l1=new Label("EMERGENCY ID");
     t1=new TextField();
    
     l2=new Label("NAME");
     t2=new TextField();

     l3=new Label("NAME");
     t3=new TextField();
    
     l4=new Label("NAME");
     t4=new TextField();

    /* AGE AND BLOODGROUP */

     l5=new Label("AGE");
     t5=new TextField();

     l6=new Label("AGE");
     t6=new TextField();

     l7=new Label("AGE");
     t7=new TextField();

     l8=new Label("BLOOD GROUP");
     t8=new TextField();

     l9=new Label("BLOOD GROUP");
     t9=new TextField();

     l10=new Label("BLOOD GROUP");
     t10=new TextField();

     b0=new Button("SEARCH");  
     b1=new Button("CLOSE");

   }



     public void setupSearchChildrensInformation()
   {    
     frm.setLayout(null);
     l1.setBounds(100,100,100,25);
     t1.setBounds(260,100,150,25);
    
     frm.setLayout(null);
     l2.setBounds(100,150,100,25);
     t2.setBounds(260,150,150,25);

     frm.setLayout(null);
     l3.setBounds(100,200,100,25);
     t3.setBounds(260,200,150,25);

     frm.setLayout(null);
     l4.setBounds(100,250,100,25);
     t4.setBounds(260,250,150,25);


    

     frm.add(l1);
     frm.add(l2);
     frm.add(l3);
     frm.add(l4);
     frm.add(t1);
     frm.add(t2);
     frm.add(t3);
     frm.add(t4); 
      
  /* AGE AND BLOODGROUP */
    
     frm.setLayout(null);
     l5.setBounds(470,150,40,25);
     t5.setBounds(520,150,100,25);

     frm.setLayout(null);
     l6.setBounds(470,200,40,25);
     t6.setBounds(520,200,100,25);

     frm.setLayout(null);
     l7.setBounds(470,250,40,25);
     t7.setBounds(520,250,100,25);

     frm.setLayout(null);
     l8.setBounds(640,150,100,25);
     t8.setBounds(760,150,100,25);

     frm.setLayout(null);
     l9.setBounds(640,200,100,25);
     t9.setBounds(760,200,100,25);

     frm.setLayout(null);
     l10.setBounds(640,250,100,25);
     t10.setBounds(760,250,100,25);

     frm.setLayout(null);
     b0.addActionListener(this);
     b0.setBounds(260,300,150,35);
     frm.setLayout(null);
     b1.addActionListener(this);
     b1.setBounds(420,300,150,35);
     frm.add(l5);
     frm.add(l6);
     frm.add(l7);
     frm.add(l8);
     frm.add(l9);
     frm.add(l10);
     frm.add(t5);
     frm.add(t6);
     frm.add(t7);
     frm.add(t8); 
     frm.add(t9);
     frm.add(t10); 
     frm.add(b0);
     frm.add(b1);
     frm.setSize(1500,1500);
     conn();
     searchData();
     frm.setVisible(true); 
}


public void getFillValue()
{
  try
  {
   a1=t1.getText();
   a2=t2.getText();
   a3=t3.getText();
   a4=t4.getText();
   a5=t5.getText();
   a6=t6.getText();
   a7=t7.getText();
   a8=t8.getText();
   a9=t9.getText();
   a10=t10.getText();
   }
   catch(Exception ex)
  {
    System.out.println("VALUR ERROR="+ex);
   }
}

public void conn()
{
 try
 { 
   Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
   con=DriverManager.getConnection("jdbc:odbc:DSNEMR");
 }
 catch(Exception ex)
 {
  System.out.println(ex);
 }
}


public void searchData()
{
  try
  {
    st=con.createStatement();
    String str=t1.getText();
    rec=st.executeQuery("Select *from cldrninfo  where emrngcid='"+str+"'");
    if(rec.next())
    {
      t2.setText(rec.getString(2));
      t3.setText(rec.getString(3));
      t4.setText(rec.getString(4));
      t5.setText(rec.getString(5));
      t6.setText(rec.getString(6));
      t7.setText(rec.getString(7));
      t8.setText(rec.getString(8));
      t9.setText(rec.getString(9));
     t10.setText(rec.getString(10));


    }
   }
   catch(Exception ex)
   {
     System.out.println(ex);
   }
}

public void setID(String ID)
{
t1.setText(ID);
}

public void actionPerformed(ActionEvent ae)
{


   if(ae.getSource()==b1)
  {
   frm.setVisible(false);
  }

}
}
