package emr;
import java.awt.*;
import java.awt.event.*;
import java.applet.*;
import java.sql.*;
public class UpdateCallerHospitalInformation extends Frame implements ActionListener
{  
   Connection con;
   Statement st;
   PreparedStatement pst;
   ResultSet rec;
   Frame frm;
   Button b0,b1,b2;
   TextField t1,t2,t3,t4,t5,t6,t7,t8;
   Label l0,l1,l2,l3,l4,l5,l6,l7,l8;
   String a1="",a2="",a3="",a4="",a5="",a6="",a7="",a8="";

 public void paint(Graphics g)
 {
   g.setColor(Color.red);
   g.drawRect(60,20,920,420);
 }
 
   public UpdateCallerHospitalInformation()
   {
     frm=new Frame("CALLER HOSPITAL INFORMATION");
     l0=new Label("HOSPITAL INFORMATION");
     l1=new Label("EMERGENCY NUMBER");
     t1=new TextField();
     l2=new Label("NAME OF HOSPITAL");
     t2=new TextField();
     l3=new Label("NAME OF 2ND HOSPITAL");
     t3=new TextField();
     l4=new Label("AMBULANCE NUMBER");
     t4=new TextField();

  /* DISTANCE AND HOSPITAL NUMBER */

     l5=new Label("DISTANCE");
     t5=new TextField();
     l6=new Label("DISTANCE");
     t6=new TextField();
     l7=new Label("HOSPITAL PHONE NO.");
     t7=new TextField();
     l8=new Label("HOSPITAL PHONE NO.");
     t8=new TextField();
     b0=new Button("SEARCH");  
     b1=new Button("UPDATE");
     b2=new Button("BACK");   
  
    }


  public void setupUpdateCallerHospitalInformation()
{    

     l0.setBounds(100,40,150,25);
     l1.setBounds(100,100,150,25);
     t1.setBounds(260,100,150,25);
     l2.setBounds(100,150,150,25);
     t2.setBounds(260,150,150,25);
     l3.setBounds(100,200,150,25);
     t3.setBounds(260,200,150,25);
     l4.setBounds(100,250,150,25);
     t4.setBounds(260,250,150,25);

    
     frm.setLayout(null);
     frm.add(l0);
     frm.add(l1);
     frm.add(l2);
     frm.add(l3);
     frm.add(l4);
     frm.add(t1);
     frm.add(t2);
     frm.add(t3);
     frm.add(t4); 

    
  /* DISTANCE AND HOSPITAL NUMBER */

     l5.setBounds(470,150,80,25);
     t5.setBounds(550,150,100,25);
     l6.setBounds(470,200,80,25);
     t6.setBounds(550,200,100,25);
     l7.setBounds(680,150,150,25);
     t7.setBounds(840,150,100,25);
     l8.setBounds(680,200,150,25);
     t8.setBounds(840,200,100,25);
     b0.addActionListener(this);
     b0.setBounds(260,300,150,30);
     b1.addActionListener(this);
     b1.setBounds(440,300,150,30);
     b2.addActionListener(this);
     b2.setBounds(630,300,150,30);

     frm.setLayout(null);
     frm.add(l5);
     frm.add(l6);
     frm.add(l7);
     frm.add(l8);
     frm.add(t5);
     frm.add(t6);
     frm.add(t7);
     frm.add(t8); 
     frm.add(b0);
     frm.add(b1);
     frm.add(b2);
     frm.setSize(600,500);
     frm.setVisible(true);

}

public void getFillValue()
{
  try
  {
   a1=t1.getText();
   a2=t2.getText();
   a3=t3.getText();
   a4=t4.getText();
   a5=t5.getText();
   a6=t6.getText();
   a7=t7.getText();
   a8=t8.getText();
   }
   catch(Exception ex)
  {
    System.out.println("VALUR ERROR="+ex);
   }
}

public void conn()
{
 try
 { 
   Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
   con=DriverManager.getConnection("jdbc:odbc:DSNEMR");
 }
 catch(Exception ex)
 {
  System.out.println(ex);
 }
}
public void putData()
{
 try
 {
   pst=con.prepareStatement("update clrhosptlinfo set namhsptl1='"+a2+"',namhsptl2='"+a3+"',amblncno='"+a4+"',dstn1='"+a5+"',dstn2='"+a6+"',hsptlphno1='"+a7+"',hsptlphno2='"+a8+"' where emrngcno='"+a1+"'");
   pst.executeUpdate();
 }
 catch(SQLException se)
 {
  System.out.println(se);
 }
}

public void searchData()
{
  try
  {
    st=con.createStatement();
    String str=t1.getText();
    rec=st.executeQuery("Select *from clrhosptlinfo  where emrngcno='"+str+"'");
    if(rec.next())
    {
      t2.setText(rec.getString(2));
      t3.setText(rec.getString(3));
      t4.setText(rec.getString(4));
      t5.setText(rec.getString(5));
      t6.setText(rec.getString(6));
      t7.setText(rec.getString(7));
      t8.setText(rec.getString(8));


    }
   }
   catch(Exception ex)
   {
     System.out.println(ex);
   }
}

public void actionPerformed(ActionEvent ae)
{
  
  if(ae.getSource()==b1)
   {  
     getFillValue();
     conn();
     putData();
   }
   else if(ae.getSource()==b0)
  {
     conn();
     searchData();
  }

}
}
/*<applet code="CallerHospitalInformation.java" height="800" width="800">
</applet>*/