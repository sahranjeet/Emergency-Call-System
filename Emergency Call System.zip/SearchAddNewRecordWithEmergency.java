package emr;
import java.awt.*;
import java.awt.event.*;
import java.applet.*;
import java.sql.*;
public class SearchAddNewRecordWithEmergency extends Frame implements ActionListener
{ 
   Connection con;
   Statement st;
   PreparedStatement pst;
   ResultSet rec;
   Frame frm;
   Button b1,b2;
   TextField t1,t2,t3,t4;
   Label l1,l2,l3,l4;
   String a1="",a2="",a3="",a4="";

  public SearchAddNewRecordWithEmergency()
  {
   frm=new Frame("ADD NEW RECORD WITH EMERGENCY");
     l1=new Label("Name Of Area");
     t1=new TextField();
     l2=new Label("Police Station Number");
     t2=new TextField();
     l3=new Label("Ambulance Number");
     t3=new TextField();   
     l4=new Label("Fire Station Number");
     t4=new TextField();
     b1=new Button("SEARCH");
     b2=new Button("CLOSE");
  }


  public void setupSearchAddNewRecordWithEmergency()
{    

     frm.setLayout(null);
     l1.setBounds(100,100,150,25);
     t1.setBounds(260,100,150,25);
    
     frm.setLayout(null);
     l2.setBounds(100,150,150,25);
     t2.setBounds(260,150,150,25);

     frm.setLayout(null);
     l3.setBounds(100,200,150,25);
     t3.setBounds(260,200,150,25);

     frm.setLayout(null);
     l4.setBounds(100,250,150,25);
     t4.setBounds(260,250,150,25);
    
     frm.setLayout(null);
     b1.addActionListener(this);
     b1.setBounds(260,300,150,25);

     frm.setLayout(null);
     b2.addActionListener(this);
     b2.setBounds(430,300,150,25);

     frm.add(l1);
     frm.add(l2);
     frm.add(l3);
     frm.add(l4);
     frm.add(t1);
     frm.add(t2);
     frm.add(t3);
     frm.add(t4); 
     frm.add(b1);
     frm.add(b2); 
     frm.setSize(1500,1500);
     conn();
     searchData(); 
     frm.setVisible(true);
}


public void getFillValue()
{
  try
  {
   a1=t1.getText();
   a2=t2.getText();
   a3=t3.getText();
   a4=t4.getText();
   }
   catch(Exception ex)
  {
    System.out.println("VALUR ERROR="+ex);
   }
}

public void conn()
{
 try
 { 
   Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
   con=DriverManager.getConnection("jdbc:odbc:DSNEMR");
 }
 catch(Exception ex)
 {
  System.out.println(ex);
 }
}
public void setID(String ID)
{
t1.setText(ID);
}


public void searchData()
{
  try
  {
    st=con.createStatement();
    String str=t1.getText();
    rec=st.executeQuery("Select *from addnewrecord where namarea='"+str+"'");
    if(rec.next())
    {
      t2.setText(rec.getString(2));
      t3.setText(rec.getString(3));
      t4.setText(rec.getString(4));
    }
   }
   catch(Exception ex)
   {
     System.out.println(ex);
   }
}

public void actionPerformed(ActionEvent ae)
{
   
  if(ae.getSource()==b2)
  {
   frm.setVisible(false);
  }

}
}
