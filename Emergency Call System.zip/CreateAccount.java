package emr;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class CreateAccount extends Frame implements ActionListener
{
    Connection con;
   Statement st;
   PreparedStatement pst;
   ResultSet rec;
   Frame frm;
   Button b1,b2;
   TextField t1,t2,t3,t4;
   Label l1,l2,l3,l4,l5;
   CheckboxGroup cb1;
   Choice d1;
   String a1="",a2="",a3="",a4="",a5="";


   public CreateAccount()
  { 
    frm=new Frame("CREATE ACCOUNT");
     l1=new Label("ENTER USER ID");
     t1=new TextField();
     l2=new Label("ENTER PASSWORD");
     t2=new TextField();
     l3=new Label("RE-ENTER PASSWORD");
     t3=new TextField(); 
     l4=new Label("SELECT SECURITY QUESTION");
     d1=new Choice();
     l5=new Label("GIVE ANSWER");
     t4=new TextField();
     b1=new Button("SAVE");
     b2=new Button("CLOSE");    
   }

   public void setupCreateAccount()
   {
     l1.setBounds(100,100,200,30);
     t1.setBounds(310,100,150,30);
     l2.setBounds(100,150,200,30);
     t2.setBounds(310,150,150,30);
     l3.setBounds(100,200,200,30);
     t3.setBounds(310,200,150,30);
     l4.setBounds(100,250,150,30);

     d1.addItem("ENTER BIRTH DATE");
     d1.addItem("ENTER LAST PASSWORD"); 
     d1.addItem("ENTER CITY NAME");
     d1.addItem("ENTER FAVOURITE FOOD");

     d1.setBounds(310,250,150,25);

     l5.setBounds(100,300,150,30);
     t4.setBounds(310,300,150,30);

     b1.addActionListener(this);
     b1.setBounds(100,350,150,40);
     b2.addActionListener(this);
     b2.setBounds(310,350,150,40);


     frm.setLayout(null);

     frm.add(l1);
     frm.add(l2);
     frm.add(l3);
     frm.add(l4);
     frm.add(d1);
     frm.add(l5); 
     frm.add(t1);
     frm.add(t2);
     frm.add(t3);
     frm.add(t4);
     frm.add(b1);
     frm.add(b2);
     frm.setSize(500,500); 
     frm.setVisible(true); 
   }


public void getFillValue()
{
  try
  {
   a1=t1.getText();
   a2=t2.getText();
   a3=t3.getText();
   a4=d1.getSelectedItem();
   a5=t4.getText();
   }
   catch(Exception ex)
  {
    System.out.println("VALUR ERROR="+ex);
   }
}

public void conn()
{
 try
 { 
   Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
   con=DriverManager.getConnection("jdbc:odbc:DSNEMR");
 }
 catch(Exception ex)
 {
  System.out.println(ex);
 }
}

public void putData()
{
 try
 {
   pst=con.prepareStatement("insert into Tacreatacc values('"+a1+"','"+a2+"','"+a3+"','"+a4+"','"+a5+"')");
   pst.executeUpdate();
 }
 catch(SQLException se)
 {
  System.out.println(se);
 }
}
public void actionPerformed(ActionEvent ae)
{
   if(ae.getSource()==b1)
   {  
     getFillValue();
     conn();
     putData();
   } 

}
}