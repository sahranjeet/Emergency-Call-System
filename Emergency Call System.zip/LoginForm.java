package emr;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;
public class LoginForm extends JFrame implements ActionListener
{
    Connection con;
   Statement st;
   PreparedStatement pst;
   ResultSet rec;
  JFrame frm;
  JLabel l1,l2,l0;
  JTextField t1,t2;
 JButton b1,b2,b3,b4;
   String a1="",a2="";
   Font f1,f2;

   public LoginForm()
   {  

    frm=new JFrame("LOGIN FORM"); 
    l0=new JLabel(""); 
    l1=new JLabel("Enter The User ID");
    t1=new JTextField();

    l2=new JLabel("Enter The Password");
    t2=new JTextField();
  
    b1=new JButton("LOGIN");
    b2=new JButton("EXIT");

    b3=new JButton("Forget Password");
    b4=new JButton("Change Password");

    f1=new Font("Arial",Font.BOLD,15);
    f2=new Font("Arial",Font.BOLD,15);
   }




  public void setupLoginForm()
 {
  frm.setLayout(null);
  l0.setBounds(250,50,300,35);
  l1.setBounds(100,100,150,25);
  t1.setBounds(250,100,150,25); 
  l2.setBounds(100,165,150,25);
  t2.setBounds(250,165,150,25);

  frm.setLayout(null);
  b1.addActionListener(this);
  b1.setBounds(450,100,150,25);
  b2.addActionListener(this);
  b2.setBounds(450,165,150,25);

  frm.setLayout(null);
  b3.addActionListener(this);
  b3.setBounds(260,245,150,25);
  b4.addActionListener(this);
  b4.setBounds(450,245,150,25);

  l0.setFont(f1);
  l1.setFont(f1);
  l2.setFont(f1);
  b1.setFont(f1);
  b2.setFont(f1);
  b3.setFont(f1);
  b4.setFont(f1);

  frm.add(l0);
  frm.add(l1);
  frm.add(l2);
  frm.add(t1);
  frm.add(t2);
  frm.add(b1);
  frm.add(b2);
  frm.add(b3);
  frm.add(b4);
  frm.setSize(1500,1500);
  frm.setVisible(true); 
 }

/*public void getFillValue()
{
  try
  {
   a1=t1.getText();
   a2=t2.getText();
   }
   catch(Exception ex)
  {
    System.out.println("VALUR ERROR="+ex);
   }
}*/

public void conn()
{
 try
 { 
   Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
   con=DriverManager.getConnection("jdbc:odbc:DSNEMR");
 }
 catch(Exception ex)
 {
  System.out.println(ex);
 }
}


public void searchData()
{
  try
  {
    st=con.createStatement();
    String str=t1.getText();
     a1=t1.getText();
     a2=t2.getText();
    rec=st.executeQuery("Select *from Tacreatacc where entrusrid='"+a1+"' and entrpaswrd='"+a2+"'");
    if(rec.next())
    {
      SearchCallerInformationButton obj=new SearchCallerInformationButton();
      obj.setupSearchCallerInformationButton();
    }
    else
     {
         l0.setText("INVALID ID OR PASSWORD");
      }
   }
   catch(Exception ex)
   {
     System.out.println(ex);
   }
}

  public void actionPerformed(ActionEvent ae)
  {
    if(ae.getSource()==b1)
  {
     conn();
     searchData();
  }
  }


}