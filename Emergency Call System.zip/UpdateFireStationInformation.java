package emr;
import java.awt.*;
import java.awt.event.*;
import java.applet.*;
import java.sql.*;
public class UpdateFireStationInformation extends Frame implements ActionListener
{ 
   Connection con;
   Statement st;
   PreparedStatement pst;
   ResultSet rec;
   Frame frm;
   Button b0,b1,b2;
   TextField t1,t2,t3,t4,t5;
   Label l1,l2,l3,l4,l5;
   String a1="",a2="",a3="",a4="",a5="";

  public UpdateFireStationInformation()
  { 
    frm=new Frame("FIRE STATION INFORMATION");
     l1=new Label("EMERGENCY ID");
     t1=new TextField();
     l2=new Label("LOCATION OF FIRE STATION");
     t2=new TextField();
     l3=new Label("FIRE STATION PH N0.");
     t3=new TextField(); 
     l4=new Label("DISTANCE OF FIRE STATION");
     t4=new TextField();
     l5=new Label("OTHER NO. OF FIRE STATION");
     t5=new TextField();
     b0=new Button("SEARCH");
     b1=new Button("UPDATE");
     b2=new Button("BACK");   
        

  }


  public void setupUpdateFireStationInformation()
{    
     l1.setBounds(100,100,150,25);
     t1.setBounds(360,100,150,25);
     l2.setBounds(100,150,200,25);
     t2.setBounds(360,150,150,25);
     l3.setBounds(100,200,250,25);
     t3.setBounds(360,200,150,25);
     l4.setBounds(100,250,250,25);
     t4.setBounds(360,250,150,25);
     l5.setBounds(100,300,250,25);
     t5.setBounds(360,300,150,25);
     b0.addActionListener(this);
     b0.setBounds(310,350,100,30);
     b1.addActionListener(this);
     b1.setBounds(420,350,100,30);
     b2.addActionListener(this);
     b2.setBounds(530,350,100,30);

     frm.setLayout(null);
     frm.add(l1);
     frm.add(l2);
     frm.add(l3);
     frm.add(l4);
     frm.add(t1);
     frm.add(t2);
     frm.add(t3);
     frm.add(t4);
     frm.add(l5);
     frm.add(t5);
     frm.add(b0);
     frm.add(b1);
     frm.add(b2);
     frm.setSize(500,500); 
     frm.setVisible(true); 

}


public void getFillValue()
{
  try
  {
   a1=t1.getText();
   a2=t2.getText();
   a3=t3.getText();
   a4=t4.getText();
   a5=t5.getText();
   }
   catch(Exception ex)
  {
    System.out.println("VALUR ERROR="+ex);
   }
}

public void conn()
{
 try
 { 
   Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
   con=DriverManager.getConnection("jdbc:odbc:DSNEMR");
 }
 catch(Exception ex)
 {
  System.out.println(ex);
 }
}
public void updateData()
{
 try
 {
   pst=con.prepareStatement("update firstsninfo set loctnfirestsn='"+a2+"',phnofirestsn='"+a3+"',distncfirestsn='"+a4+"',othernofirstsn='"+a5+"' where emrngcid='"+a1+"'");
   pst.executeUpdate();
 }
 catch(SQLException se)
 {
  System.out.println(se);
 }
}

public void searchData()
{
  try
  {
    st=con.createStatement();
    String str=t1.getText();
    rec=st.executeQuery("Select *from firstsninfo where emrngcid='"+str+"'");
    if(rec.next())
    {
      t2.setText(rec.getString(2));
      t3.setText(rec.getString(3));
      t4.setText(rec.getString(4));
      t5.setText(rec.getString(5));

    }
   }
   catch(Exception ex)
   {
     System.out.println(ex);
   }
}
public void actionPerformed(ActionEvent ae)
{
  if(ae.getSource()==b1)
   {  
     getFillValue();
     conn();
     updateData();
   }
  else if(ae.getSource()==b0)
  {
     conn();
     searchData();
  }

}
}
