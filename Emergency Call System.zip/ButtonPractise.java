import java.awt.*;
import java.awt.event.*;
import java.applet.*;
public class ButtonPractise extends Applet implements ActionListener
{ 
  
   Button b1,b2;
   TextField t1,t2,t3;
   Label l1,l2,l3;
   public void init()
   {    
     l1=new Label("EMERGENCY ID");
     t1=new TextField();
     setLayout(null);
     l1.setBounds(100,100,100,25);
     t1.setBounds(260,100,150,25);
    
    
     l2=new Label("CALLER NAME");
     t2=new TextField();
     setLayout(null);
     l2.setBounds(100,150,100,25);
     t2.setBounds(260,150,150,25);

     l3=new Label("FATHER NAME");
     t3=new TextField();
     setLayout(null);
     l3.setBounds(100,200,100,25);
     t3.setBounds(260,200,150,25);

     b1=new Button("SEARCH RECORD");
     setLayout(null);
     b1.addActionListener(this);
     b1.setBounds(100,250,150,50);

     b2=new Button("PRINT RECORD");
     setLayout(null);
     b2.addActionListener(this);
     b2.setBounds(270,250,150,50);
     add(b1);
     add(b2); 
     add(l2);
     add(l1);  
     add(l3);
     add(t1); 
     add(t2);
     add(t3);

}
public void actionPerformed(ActionEvent ae)
{


}
}
/*<applet code="ButtonPractise.java" height="800" width="1200">
</applet>*/
     

